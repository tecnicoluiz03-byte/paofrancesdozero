const caktoScript = document.createElement('script');
caktoScript.src = 'https://caktoscripts.nyc3.cdn.digitaloceanspaces.com/upsell.js';
caktoScript.addEventListener('error', () => {
  document.getElementById('offer-status').hidden = false;
});
document.body.appendChild(caktoScript);
